




export const addSilkAfterPaymentController = async () => {
    try {

    }catch (failure) {

    }
}
